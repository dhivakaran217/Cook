import SwiftUI

public extension Color {
    static var hoverColor: Color { .gray.opacity(0.1) }
}
